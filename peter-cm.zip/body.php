<!-- Spinner Start -->
<div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
    <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
        <span class="sr-only">Loading...</span>
    </div>
</div>
<!-- Spinner End -->

<div class="container">
    <div class="row g-5">
        <div class="col-lg-4 sticky-lg-top vh-100">
            <div class="d-flex flex-column h-100 text-center overflow-auto shadow">
                <img class="w-100 img-fluid mb-4" src="img/profile/profile.jpg" alt="Image">
                <h1 class="text-primary mt-2">Peter Musonda</h1>
                <div class="mb-4" style="height: 22px;">
                    <h4 class="typed-text-output d-inline-block text-light"></h4>
                    <div class="typed-text d-none">Graphic Designer, Web Designer, Front End Developer, <!-- Apps Designer, Apps Developer--></div>
                </div>
                <div class="d-flex justify-content-center mt-auto mb-3">
                    <a class="btn btn-secondary btn-square mx-1" href="https://wa.link/0v65i3"><i class="fab fa-whatsapp"></i></a>
                    <a class="btn btn-secondary btn-square mx-1" href="https://www.facebook.com/peter.musonda.12576"><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-secondary btn-square mx-1" href="https://github.com/Technical-CM"><i class="fab fa-github "></i></a>
                    <a class="btn btn-secondary btn-square mx-1" href="https://www.instagram.com/petermusonda381?igsh=OGQ5ZDc2ODk2ZA=="><i class="fab fa-instagram"></i></a>
                </div>
                <div class="d-flex align-items-end justify-content-between border-top">
                    <a href="" class="btn w-50 border-end">Download CV</a>
                    <a href="#contact" class="btn w-50 btn-scroll">Contact Me</a>
                </div>
            </div>
        </div>
        <div class="col-lg-8">

        <!-- About Start -->
            <section class="py-5 border-bottom wow fadeInUp" data-wow-delay="0.1s">
                <h1 class="title pb-3 mb-5">About Me</h1>
                
                <p>Welcome to my creative realm, where pixels and vectors converge to create visual symphonies! With almost a decade of navigating the ever-evolving landscape of graphic design, I've mastered the art of transforming ideas into captivating visual narratives. My journey has been a thrilling exploration of colors, shapes, and pixels, where each project tells a unique story.
                <br>
                <br>
                In this ever-evolving world of design, I am your seasoned guide, steering through the realms of visual communication, branding, and design alchemy. Proficiency in Adobe Creative Suite (consider it my design playground) - Photoshop, Illustrator, InDesign, coupled with the finesse of Corel Draw and the magic touch of Wilcom Embroidery Designer, defines the palette with which I paint dreams and concepts into reality.
                <br>
                <br>
                Let's embark on a journey where creativity knows no bounds, and design is not just a profession but a passion. From brainstorming sessions to the final pixel, my expertise is your canvas, and together, we'll craft designs that not only speak but sing!
                <br>
                <br>
                I am the maestro of design, orchestrating impactful and visually stunning creations that resonate with both your vision and your audience. Welcome, not just to a portfolio, but to an immersive experience where design transcends the ordinary, and creativity dances on the edge of possibility.</p>
                
                <div class="row mb-4">
                    <div class="col-sm-6 py-1">
                        <span class="fw-medium text-primary">Name:</span> Peter Musonda
                    </div>
                    <div class="col-sm-6 py-1">
                        <span class="fw-medium text-primary">Facebook:</span> Technical Media
                    </div>
                    <div class="col-sm-6 py-1">
                        <span class="fw-medium text-primary">Phone:</span> +260 97 9930483
                    </div>
                    <div class="col-sm-6 py-1">
                        <span class="fw-medium text-primary">Google Ad:</span> Technical Media
                    </div>
                    <div class="col-sm-6 py-1">
                        <span class="fw-medium text-primary">Email:</span> petermusonda381@gmail.com
                    </div>
                    <div class="col-sm-6 py-1">
                        <span class="fw-medium text-primary">Email:</span> tm.technicalmedia@gmail.com
                    </div>
                    <div class="col-sm-6 py-1">
                        <span class="fw-medium text-primary">Address:</span> Off Old Mungwi Road, Farm No. 3259/M, Lusaka, Zambia.
                    </div>
                    <div class="col-sm-6 py-1">
                        <span class="fw-medium text-primary">Education:</span> SEE ATTACHED FILES
                    </div>
                </div>
            <!-- About End -->

            <!-- Skills Start -->
            <section class="py-5 border-bottom wow fadeInUp" data-wow-delay="0.1s">
                <h1 class="title pb-3 mb-5">Key Skills:</h1>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="skill mb-4">
                            <div class="d-flex justify-content-between">
                                <p class="mb-2">Adobe Creative Suite: <br>Photoshop, Illustrator, InDesign</p>
                                <p class="mb-2"></p>
                            </div>
                            <div class="progress">
                                <div class="progress-bar bg-primary" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                        <div class="skill mb-4">
                            <div class="d-flex justify-content-between">
                                <p class="mb-2">Corel Draw</p>
                                <p class="mb-2"></p>
                            </div>
                            <div class="progress">
                                <div class="progress-bar bg-warning" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                        <div class="skill mb-4">
                            <div class="d-flex justify-content-between">
                                <p class="mb-2">Wilcom Embroidery Designer</p>
                                <p class="mb-2"></p>
                            </div>
                            <div class="progress">
                                <div class="progress-bar bg-danger" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="skill mb-4">
                            <div class="d-flex justify-content-between">
                                <p class="mb-2">Web Design <br>Front End Development </p>
                                <p class="mb-2"></p>
                            </div>
                            <div class="progress">
                                <div class="progress-bar bg-danger" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                        <div class="skill mb-4">
                            <div class="d-flex justify-content-between">
                                <p class="mb-2">Printing Machine Operation</p>
                                <p class="mb-2"></p>
                            </div>
                            <div class="progress">
                                <div class="progress-bar bg-success" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                        <div class="skill mb-4">
                            <div class="d-flex justify-content-between">
                                <p class="mb-2">Branding</p>
                                <p class="mb-2"></p>
                            </div>
                            <div class="progress">
                                <div class="progress-bar bg-info" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Skills End -->

            <!-- Expericence Start -->
            <section class="py-5 wow fadeInUp" data-wow-delay="0.1s">
                <h1 class="title pb-3 mb-5">Professional Experience:</h1>
                <div class="border-start border-2 border-light pt-2 ps-5">
                    
                    <div class="position-relative mb-4">
                        <span class="bi bi-arrow-right fs-4 text-light position-absolute" style="top: -5px; left: -50px;"></span>
                        <h5 class="mb-1">Graphic Designer</h5>
                        <p class="mb-2">Tulumbe Media Limited Company | <small>2021 - 2024</small></p>
                        <p>In my role as a Graphic Designer at Tulumbe Media Limited Company, I play a pivotal role in creating visually appealing designs for a diverse range of projects. My responsibilities included conceptualizing and executing designs for print materials, branding collateral, and digital media. I also demonstrated proficiency in operating printing machines, ensuring the highest quality output.</p>
                    </div>
                    <div class="position-relative mb-4">
                        <span class="bi bi-arrow-right fs-4 text-light position-absolute" style="top: -5px; left: -50px;"></span>
                        <h5 class="mb-1">Rothel Digital Print</h5>
                        <p class="mb-2">Graphic Designer | <small>2018 - 2021</small></p>
                        <p>At Rothel Digital Print, I assumed the position as a Graphic Designer, overseeing the end-to-end design process from ideation to execution. My responsibilities included managing a team of designers, fostering a creative environment, and liaising with clients to understand and translate their vision into compelling visual solutions. This experience enhanced my project management skills and reinforced my commitment to delivering excellence in every design endeavor.</p>
                    </div>
                    <div class="position-relative mb-4">
                        <span class="bi bi-arrow-right fs-4 text-light position-absolute" style="top: -5px; left: -50px;"></span>
                        <h5 class="mb-1">Web Designer and Developer</h5>
                        <p class="mb-2">Zamjob News | <small>2023 - 2024</small></p>
                        <p>In my capacity as a Web Designer and Developer, I seamlessly blend creativity with functionality. I specialize in translating brand identities into engaging online experiences. From concept to code, I craft responsive and visually stunning website that not only captivate audiences but also prioritize a seamless user experience. Proficient in front-end development, I ensure that every pixel serves a purpose, aligning design aesthetics with the latest web standards. This dual expertise brings an added layer to my design capabilities, allowing for a holistic approach to visual communication across both traditional and digital mediums.</p>
                    </div>
                    <div class="position-relative mb-4">
                        <span class="bi bi-arrow-right fs-4 text-light position-absolute" style="top: -5px; left: -50px;"></span>
                        <h5 class="mb-1">Freelance Graphic Designer</h5>
                        <p class="mb-2">Technical Meida | <small>2016 - 2024</small></p>
                        <p>As a freelance Graphic Designer, I had the privilege of working with various clients across different industries. This experience allowed me to further diversify my skill set and develop a keen understanding of client needs. My projects ranged from logo design and branding to promotional materials and digital assets.</p>
                    </div>

                </div>
            </section>
            <!-- Expericence End -->

            <!-- Portfolio Highlights -->
            <section class="py-5 border-bottom wow fadeInUp" data-wow-delay="0.1s">
                <h1 class="title pb-3 mb-5">Portfolio Highlights:</h1>
                <div class="row g-4">
                    <div class="col-md-6">
                        <div class="service-item">
                            <i class="fa fa-2x fa-laptop-code mx-auto mb-4"></i>
                            <h5 class="mb-2">Web Design and Development</h5>
                            <p class="mb-0">
                                Translated brand identity into an engaging and responsive website design.
                                <br>
                                Implemented front-end development, ensuring a seamless user experience across devices.</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="service-item">
                            <i class="fab fa-2x fa fa-print mx-auto mb-4"></i>
                            <h5 class="mb-2">Print Campaign</h5>
                            <p class="mb-0">
                                Developed eye-catching visuals for a high-profile event, effectively promoting it through print materials such as posters, banners, and flyers.
                                Ensured brand consistency and adherence to the event's theme throughout the campaign.</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="service-item">
                            <i class="fa fa-2x fa-search mx-auto mb-4"></i>
                            <h5 class="mb-2">Profession Lead</h5>
                            <p class="mb-0">
                                I lead creative developing and implementing design concepts for high-profile clients. 
                                Collaborating closely with clients and stakeholders, I ensured that design solutions not only met but exceeded expectations. This strategic thinking and leadership skills contributes to the success of my work.</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="service-item">
                            <i class="fa fa-2x fa-edit mx-auto mb-4"></i>
                            <h5 class="mb-2">Brand Identity and Content Creating</h5>
                            <p class="mb-0">
                                Created a distinctive and memorable brand identity that resonated with the target audience.
                                <br>
                                Designed a comprehensive set of branding collateral, including business cards, letterheads, and packaging materials</p>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Portfolio Highlights End -->

            <!-- Portfolio Start -->
            <section class="py-5 border-bottom wow fadeInUp" data-wow-delay="0.1s">
                <h1 class="title pb-3 mb-5">Portfolio</h1>
                <div class="row">
                    <div class="col-12">
                        <div class="row">
                            <div class="col-12 text-center mb-2">
                                <ul class="list-inline mb-4" id="portfolio-flters">
                                    <li class="btn btn-secondary active"  data-filter="*"><i class="fa fa-star me-2"></i>All</li>
                                    <li class="btn btn-secondary" data-filter=".first"><i class="fa fa-laptop me-2"></i>View 0.1</li>
                                    <li class="btn btn-secondary" data-filter=".second"><i class="fa fa-laptop me-2"></i>View 0.2</li>
                                </ul>
                            </div>
                        </div>
                        <div class="row portfolio-container">
                            <div class="col-md-6 mb-4 portfolio-item first">
                                <div class="position-relative overflow-hidden mb-2">
                                    <img class="img-fluid w-100" src="img/portfolio-1.jpg" alt="">
                                    <div class="portfolio-btn d-flex align-items-center justify-content-center">
                                        <a href="img/portfolio-1.jpg" data-lightbox="portfolio">
                                            <i class="bi bi-plus text-light"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-4 portfolio-item second">
                                <div class="position-relative overflow-hidden mb-2">
                                    <img class="img-fluid w-100" src="img/portfolio-2.jpg" alt="">
                                    <div class="portfolio-btn d-flex align-items-center justify-content-center">
                                        <a href="img/portfolio-2.jpg" data-lightbox="portfolio">
                                            <i class="bi bi-plus text-light"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-4 portfolio-item first">
                                <div class="position-relative overflow-hidden mb-2">
                                    <img class="img-fluid w-100" src="img/portfolio-3.jpg" alt="">
                                    <div class="portfolio-btn d-flex align-items-center justify-content-center">
                                        <a href="img/portfolio-3.jpg" data-lightbox="portfolio">
                                            <i class="bi bi-plus text-light"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-4 portfolio-item second">
                                <div class="position-relative overflow-hidden mb-2">
                                    <img class="img-fluid w-100" src="img/portfolio-4.jpg" alt="">
                                    <div class="portfolio-btn d-flex align-items-center justify-content-center">
                                        <a href="img/portfolio-4.jpg" data-lightbox="portfolio">
                                            <i class="bi bi-plus text-light"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Portfolio End -->

            <!-- Refferences Start -->
            <section class="py-5 border-bottom wow fadeInUp" data-wow-delay="0.1s">
                <h1 class="title pb-3 mb-5">Refferences</h1>
                <div class="owl-carousel testimonial-carousel">
                    <div class="text-left">
                        <i class="fa fa-3x fa-quote-left text-primary mb-4"></i>
                        <p class="fs-4 mb-4">As a Graphic Designer, Peter Musonda consistently demonstrated a keen eye for design, attention to detail, and a commitment to delivering high-quality work. The ability to conceptualize and execute creative ideas was truly impressive as he was a valuable asset to our team, contributing not only to the visual appeal of our projects but also to the overall success of our campaigns. I highly recommend Peter Musonda for any creative endeavor.</p>
                        <div class="d-flex align-items-center">
                            <img class="img-fluid" src="img/refference/testimonial-1.jpg" style="width: 60px; height: 60px;">
                            <div class="ps-3">
                                <p class="text-primary fs-5 mb-1">Tulumbe Media Limited</p>
                                <i>tulumbe.media@gmail.com</i>
                            </div>
                        </div>
                    </div>
                    <div class="text-left">
                        <i class="fa fa-3x fa-quote-left text-primary mb-4"></i>
                        <p class="fs-4 mb-4">
                            Having Peter Musonda as a Graphic Designer was a transformative experience. 
                            Peter not only brought a high level of creativity to the table but also demonstrated strong leadership skills. 
                            His strategic thinking and ability to guide a creative team to produce exceptional designs was instrumental in the success of several jobs completed.
                            I can confidently say that Peter Musonda is not only a skilled Graphic Designer but also a reliable and collaborative professional.</p>
                        <div class="d-flex align-items-center">
                            <img class="img-fluid" src="img/refference/rothel_digital_print.jpg" style="width: 60px; height: 60px;">
                            <div class="ps-3">
                                <p class="text-primary fs-5 mb-1">Rothel Digital Print</p>
                                <i>rotheldigitalprint@gmail.com</i>
                            </div>
                        </div>
                    </div>
                    <div class="text-left">
                        <i class="fa fa-3x fa-quote-left text-primary mb-4"></i>
                        <p class="fs-4 mb-4">
                            Peter demonstrateda a blend of creativity and leadership not only excelled in graphic design but also embraced web design and development with impressive adaptability. 
                            <br>He ensured our online presence aligned seamlessly with our brand. I wholeheartedly endorse Peter Musonda for any role requiring a mix of creativity, leadership, and expertise in both graphic and web design.</p>
                        <div class="d-flex align-items-center">
                            <img class="img-fluid" src="img/refference/testimonial-3.jpg" style="width: 60px; height: 60px;">
                            <div class="ps-3">
                                <p class="text-primary fs-5 mb-1">Zamjob News</p>
                                <i>info@zamjob.co.zm</i>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Refference End -->

            <!-- Contact Start -->
            <section class="py-5 wow fadeInUp" data-wow-delay="0.1s" id="contact">
                <h1 class="title pb-3 mb-5">Contact Me</h1>
                <p class="mb-4">Find my contact details below or click the icons below my profile to contect me.</a></p>
                
            <div class="row mb-4">
                <div class="col-sm-6 py-1">
                    <span class="fw-medium text-primary">Name:</span> Peter Musonda
                </div>
                <div class="col-sm-6 py-1">
                    <span class="fw-medium text-primary">Facebook:</span> Technical Media
                </div>
                <div class="col-sm-6 py-1">
                    <span class="fw-medium text-primary">Phone:</span> +260 97 9930483
                </div>
                <div class="col-sm-6 py-1">
                    <span class="fw-medium text-primary">Google Ad:</span> Technical Media
                </div>
                <div class="col-sm-6 py-1">
                    <span class="fw-medium text-primary">Email:</span> petermusonda381@gmail.com
                </div>
                <div class="col-sm-6 py-1">
                    <span class="fw-medium text-primary">Email:</span> tm.technicalmedia@gmail.com
                </div>
                <div class="col-sm-6 py-1">
                    <span class="fw-medium text-primary">Address:</span> Off Old Mungwi Road, Farm No. 3259/M, Lusaka, Zambia.
                </div>
                <div class="col-sm-6 py-1">
                    <span class="fw-medium text-primary">Education:</span> SEE ATTACHED FILES
                </div>
            </div>

            <!-- Footer Start -->
            <section class="wow fadeIn" data-wow-delay="0.1s">
                <div class="bg-secondary text-light text-center p-5">
                    <div class="d-flex justify-content-center mb-4">
                        <a class="btn btn-secondary btn-square mx-1" href="https://wa.link/0v65i3"><i class="fab fa-whatsapp"></i></a>
                    <a class="btn btn-secondary btn-square mx-1" href="https://www.facebook.com/peter.musonda.12576"><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-secondary btn-square mx-1" href="https://github.com/Technical-CM"><i class="fab fa-github "></i></a>
                    <a class="btn btn-secondary btn-square mx-1" href="https://www.instagram.com/petermusonda381?igsh=OGQ5ZDc2ODk2ZA=="><i class="fab fa-instagram"></i></a>
                    </div>
                    <div class="d-flex justify-content-center mb-3">
                        <a class="text-light px-3 border-end" href="#">Privacy</a>
                        <a class="text-light px-3 border-end" href="#">Terms</a>
                        <a class="text-light px-3 border-end" href="#">FAQs</a>
                        <a class="text-light px-3" href="#">Help</a>
                    </div>
                    
                    <p class="m-0">&copy; Peter Musonda <a href="#">Thank You</a></p>
                </div>
            </section>
            <!-- Footer End -->
        </div>
    </div>
</div>


<!-- Back to Top -->
<a href="#" class="back-to-top"><i class="fa fa-angle-double-up"></i></a>