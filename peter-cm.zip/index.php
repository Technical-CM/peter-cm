<?php
session_start();
?>

<!DOCTYPE html>

<html lang="en">

<!--head starts -->
<head>
    <?php include 'head.php'; ?>
</head>
<!--head ends -->

    <body>
        <!-- spinner starts -->
        <!-- spinner end -->

        <!-- main starts -->
        <?php include 'body.php'; ?>
        <!-- main ends -->


        <!--  scripts starts -->
        <?php include 'scripts.php'; ?>
        <!--  scripts ends -->
    </body>

</html>